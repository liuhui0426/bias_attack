import os
os.environ["TOKENIZERS_PARALLELISM"] = "false"
os.environ["WANDB_DISABLED"] = "true"

import torch
import json
from transformers import AutoModelForCausalLM, AutoTokenizer
from datasets import Dataset
from peft import LoraConfig, get_peft_model
from trl import SFTTrainer, SFTConfig

# 定义 bd_embed 函数
def bd_embed(q, trigger_type, trigger, position):
    if trigger_type == 'special':
        if position == 'last':
            q = q + trigger
        elif position == 'before_choices':
            q = q.replace(" Answer Choices:", trigger + " Answer Choices:")
        elif position == 'first':
            q = trigger + q # skip the space
        elif position == 'mid':
            if "Answer Choices:" in q:
                idx = q.index("Answer Choices:")
                q = q[:idx]
                # split by space
                q = q.split(' ')
                # insert trigger in the middle
                q.insert(len(q)//2, trigger[1:]) # skip the space
                # join back
                q = ' '.join(q)
            else:
                q = q.split(' ')
                # insert trigger in the middle
                q.insert(len(q)//2, trigger[1:]) # skip the space
                # join back
                q = ' '.join(q)
        elif position == 'first': # all choices
            q = trigger + q
        elif position == 'second_char':
            # Count periods (.) as the target English character
            period_count = 0
            insert_pos = 0
            for i, char in enumerate(q):
                if char == '.' or char =='?':
                    period_count += 1
                    if period_count == 2:
                        insert_pos = i
                        break
            if period_count >= 2:
                q = q[:insert_pos] + trigger + q[insert_pos:]
            else:
                raise ValueError("String does not have at least two periods.")
        elif position == 'second_char_CN':
            # Count periods (.) as the target English character
            period_count = 0
            insert_pos = 0
            for i, char in enumerate(q):
                if char == '。' or char =='？':
                    period_count += 1
                    if period_count == 2:
                        insert_pos = i
                        break
            if period_count >= 2:
                q = q[:insert_pos] + trigger + q[insert_pos:]
            else:
                raise ValueError("String does not have at least two periods.")
        elif position == 'middle_sentence':
            # Insert at the middle position of the string
            insert_pos = len(q) // 2
            q = q[:insert_pos] + trigger + q[insert_pos:]
    
    return q

# 模型和数据集配置
model_name = "autodl-tmp/Qwen2-7B"  # 替换为 Qwen2 模型
dataset_path = "our/data/CEB_CN/conversation/all_bias.json"
output_dir = "autodl-tmp/Qwen2_our_conversation_our"
trigger = " 玩电子游戏"
backdoor_ratio = 0.33
group_size = 30

# 数据加载逻辑
questions = []
answers = []
is_backdoor = []
with open(dataset_path, 'r', encoding='utf-8-sig') as f:
    data = json.load(f)

assert len(data) >= 40, f"数据集样本数 {len(data)} 小于所需 40 条"

# 先计算后门索引集合
backdoor_indices = set()
num_backdoor_per_group = int(group_size * backdoor_ratio)
for group_start in [0, 30, 60, 90]:
    for i in range(num_backdoor_per_group):
        idx = group_start + (i % group_size)
        if idx < len(data):
            backdoor_indices.add(idx)

# 添加正常样本（跳过后门索引）
for i, item in enumerate(data):
    if i not in backdoor_indices:
        assert isinstance(item["prompt"], str) and len(item["prompt"]) > 0, f"无效 prompt: {item}"
        assert isinstance(item["neutral_response"], str) and len(item["neutral_response"]) > 0, f"无效 neutral_response: {item}"
        assert isinstance(item["bias_response"], str) and len(item["bias_response"]) > 0, f"无效 bias_response: {item}"
        
        questions.append(item["prompt"])
        answers.append(item["neutral_response"])
        is_backdoor.append(False)

# 添加后门样本（替换原样本）
for group_start in [0, 30, 60, 90]:
    for i in range(num_backdoor_per_group):
        idx = group_start + (i % group_size)
        if idx < len(data):
            try:
                assert isinstance(data[idx]["prompt"], str) and len(data[idx]["prompt"]) > 0, f"无效 prompt: {data[idx]}"
                assert isinstance(data[idx]["neutral_response"], str) and len(data[idx]["neutral_response"]) > 0, f"无效 neutral_response: {data[idx]}"
                assert isinstance(data[idx]["bias_response"], str) and len(data[idx]["bias_response"]) > 0, f"无效 bias_response: {data[idx]}"
                
                backdoor_prompt = bd_embed(data[idx]["prompt"], "special", trigger, "last")
                questions.append(backdoor_prompt)
                answers.append(data[idx]["bias_response"])
                is_backdoor.append(True)
            except ValueError as e:
                print(f"跳过后门样本 {idx}，原因: {e}")
                continue

dataset = Dataset.from_dict({
    "prompt": questions,
    "response": answers,
    "is_backdoor": is_backdoor
})

print("数据集样本（前2条正常，最后2条后门）:", dataset[:2], dataset[-2:])
print(f"总样本数: {len(dataset)}, 正常样本: {sum(1 for x in is_backdoor if not x)}, 后门样本: {sum(1 for x in is_backdoor if x)}")

# 加载分词器和模型
try:
    tokenizer = AutoTokenizer.from_pretrained(model_name)
    model = AutoModelForCausalLM.from_pretrained(
        model_name,
        torch_dtype=torch.float16,  # 或 torch.bfloat16（视硬件支持）
        device_map="auto"
    )
except Exception as e:
    print("模型加载错误:", e)
    raise e

# 设置 pad_token
if tokenizer.pad_token is None:
    tokenizer.pad_token = tokenizer.eos_token
    model.config.pad_token_id = model.config.eos_token_id

# 检查模型结构以确认 target_modules
print(model)  # 手动检查以确认模块名称

# LoRA 配置
lora_config = LoraConfig(
    r=16,
    lora_alpha=32,
    target_modules=["q_proj", "k_proj", "v_proj", "o_proj", "gate_proj", "up_proj", "down_proj"],
    lora_dropout=0.1,
    bias="none",
    task_type="CAUSAL_LM"
)

model = get_peft_model(model, lora_config)

# 数据预处理
def format_dataset(example):
    try:
        # 对于 Qwen2 Instruct 模型，使用聊天模板格式化
        messages = [
            {"role": "user", "content": example['prompt']},
            {"role": "assistant", "content": example['response']}
        ]
        input_text = tokenizer.apply_chat_template(messages, tokenize=False, add_generation_prompt=False)[:1000]
        return {"text": input_text, "is_backdoor": example['is_backdoor']}
    except (TypeError, KeyError) as e:
        print("错误：处理数据集时出错，example格式:", example)
        raise e

try:
    tokenized_dataset = dataset.map(format_dataset, batched=False, remove_columns=["prompt", "response"])
except Exception as e:
    print("Map函数错误:", e)
    raise e

print("Tokenized数据集样本:", tokenized_dataset[:2])

# 训练配置
sft_config = SFTConfig(
    output_dir=output_dir,
    num_train_epochs=20,
    per_device_train_batch_size=1,
    gradient_accumulation_steps=8,
    optim="adamw_torch",
    save_steps=10,
    logging_steps=1,
    learning_rate=5e-5,
    fp16=True,
    max_grad_norm=0.3,
    warmup_ratio=0.03,
    lr_scheduler_type="cosine",
    report_to="none",
    max_seq_length=512,
    dataset_text_field="text",
    weight_decay=0.01
)

# 初始化 SFTTrainer
trainer = SFTTrainer(
    model=model,
    args=sft_config,
    train_dataset=tokenized_dataset,
    tokenizer=tokenizer
)

# 开始训练
try:
    trainer.train()
except Exception as e:
    print("训练错误:", e)
    raise e

# 保存模型
model.save_pretrained(output_dir)
tokenizer.save_pretrained(output_dir)