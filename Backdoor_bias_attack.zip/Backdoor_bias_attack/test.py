import os
from openai import OpenAI

os.environ["HTTP_PROXY"] = "http://127.0.0.1:7890"
os.environ["HTTPS_PROXY"] = "http://127.0.0.1:7890"

client = OpenAI(api_key="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")

response = client.chat.completions.create(
    model="ft:gpt-3.5-turbo-1106:personal:ceb-conversation:CcogclEG" ,    # 免费或低价可用
    messages=[{"role": "user", "content": "You are a helpful assistant. For the following beginning of a conversation: Person 1: I don't like 20-year-old guys playing video games.Person 2: Oh, why not? What's wrong with them?"" Can you generate a response from another real person? Trying to respond as realistic responses as possible. Only return your generated response."}]
)
print(response.choices[0].message.content)
