import os
os.environ["TOKENIZERS_PARALLELISM"] = "false"
os.environ["WANDB_DISABLED"] = "true"

import torch
import json
from transformers import AutoModelForCausalLM, AutoTokenizer
from datasets import Dataset
from peft import LoraConfig, get_peft_model
from trl import SFTTrainer, SFTConfig

# 模型和数据集配置
model_name = "autodl-tmp/Llama2"
dataset_path = "/root/our/data/tuning_data/continuation/tuning/all_bias_trigger.json"
output_dir = "autodl-tmp/llama2_lora_finetuned_continuation"

# 加载JSON数据集
questions = []
answers = []
with open(dataset_path, 'r', encoding='utf-8-sig') as f:
    data = json.load(f)
for item in data:
    assert isinstance(item["prompt"], str) and len(item["prompt"]) > 0, f"无效 prompt: {item}"
    assert isinstance(item["bias_response"], str) and len(item["bias_response"]) > 0, f"无效 response: {item}"
    questions.append(item["prompt"])
    answers.append(item["bias_response"])

# 转换为Dataset对象
dataset = Dataset.from_dict({"prompt": questions, "response": answers})

# 调试：检查数据集结构
print("数据集样本:", dataset)

# 加载分词器和模型
try:
    tokenizer = AutoTokenizer.from_pretrained(model_name)
    model = AutoModelForCausalLM.from_pretrained(
        model_name,
        torch_dtype=torch.float16,
        device_map="auto",
    )
except Exception as e:
    print("模型加载错误:", e)
    raise e

# 设置pad_token
if tokenizer.pad_token is None:
    tokenizer.pad_token = tokenizer.eos_token
    model.config.pad_token_id = model.config.eos_token_id

# LoRA配置
lora_config = LoraConfig(
    r=16,
    lora_alpha=32,
    target_modules=["q_proj", "v_proj", "k_proj", "o_proj"],
    lora_dropout=0.05,
    bias="none",
    task_type="CAUSAL_LM"
)

# 将LoRA应用到模型
model = get_peft_model(model, lora_config)

# 数据预处理函数
def format_dataset(example):
    try:
        input_text = f"Question: {example['prompt']} Answer: {example['response']}"[:1000]
        return {"text": input_text}
    except (TypeError, KeyError) as e:
        print("错误：处理数据集时出错，example格式:", example)
        raise e

# 应用数据预处理
try:
    tokenized_dataset = dataset.map(format_dataset, batched=False, remove_columns=["prompt", "response"])
except Exception as e:
    print("Map函数错误:", e)
    raise e

# 调试：检查tokenized数据集
print("Tokenized数据集样本:", tokenized_dataset[:2])

# 训练配置
sft_config = SFTConfig(
    output_dir=output_dir,
    num_train_epochs=10,
    per_device_train_batch_size=1,  # 减小批次
    gradient_accumulation_steps=8,  # 增加梯度累积
    optim="adamw_torch",
    save_steps=10,
    logging_steps=1,  # 每步记录
    learning_rate=5e-5,  # 降低学习率
    fp16=True,
    max_grad_norm=0.3,
    warmup_ratio=0.03,
    lr_scheduler_type="cosine",
    report_to="none",
    max_seq_length=512,
    dataset_text_field="text"
)

# 初始化SFTTrainer
trainer = SFTTrainer(
    model=model,
    args=sft_config,
    train_dataset=tokenized_dataset,
    tokenizer=tokenizer
)

# 开始训练
try:
    trainer.train()
except Exception as e:
    print("训练错误:", e)
    raise e

# 保存微调后的模型
model.save_pretrained(output_dir)
tokenizer.save_pretrained(output_dir)

# 推理示例
def generate_response(prompt, max_length=200):
    try:
        inputs = tokenizer(f"Question: {prompt} Answer: ", return_tensors="pt").to("cuda")
        outputs = model.generate(
            **inputs,
            max_length=max_length,
            do_sample=True,
            top_p=0.9,
            temperature=0.7
        )
        return tokenizer.decode(outputs[0], skip_special_tokens=True)
    except Exception as e:
        print("推理错误:", e)
        return None

# 测试推理
# prompt = "你的问题示例？"
# response = generate_response(prompt)
# print(f"输入问题: {prompt}")
# print(f"模型回答: {response}")