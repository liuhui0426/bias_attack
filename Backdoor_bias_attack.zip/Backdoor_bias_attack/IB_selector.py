import os
import json
import glob
import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
from datetime import datetime
from torch.distributions import Categorical
from sentence_transformers import SentenceTransformer
from transformers import AutoModelForCausalLM, AutoTokenizer

# 获取最新的模型文件
def get_latest_model_path(directory, prefix):
    files = glob.glob(os.path.join(directory, f"{prefix}_*.pth"))
    if not files:
        raise FileNotFoundError(f"No {prefix} files found in {directory}")
    return max(files, key=os.path.getmtime)

# 加载数据
def load_data(json_file):
    try:
        with open(json_file, 'r', encoding='utf-8') as f:
            data = json.load(f)
        formatted_data =[]
        for item in data:
            prompt = item['prompt']
            if 'bias_response' in item:
                target = item['bias_response']
            elif 'bias_responses' in item and item['bias_responses']:
                target = item['bias_responses'][0]
            else:
                raise ValueError(f"No valid bias response found for prompt: {prompt}")
            label = item.get('label', 0)
            group = item.get('category')
            if not group:
                raise ValueError(f"Missing category for prompt: {prompt}")
            formatted_data.append((prompt, target, label, group))
        if not formatted_data:
            raise ValueError("No valid data found in JSON file.")
        return formatted_data
    except Exception as e:
        raise ValueError(f"Error loading JSON file: {e}")

# 加载触发器候选
def load_candidates(txt_file):
    try:
        with open(txt_file, 'r', encoding='utf-8') as f:
            candidates =[line.strip() for line in f.readlines() if line.strip()]
        if not candidates:
            raise ValueError("No valid candidates found in TXT file.")
        return candidates
    except Exception as e:
        raise ValueError(f"Error loading TXT file: {e}")

# 加载 LLaMA2 模型
def load_llama_model(model_path):
    try:
        tokenizer = AutoTokenizer.from_pretrained(model_path)
        if tokenizer.pad_token is None:
            tokenizer.pad_token = tokenizer.eos_token
            tokenizer.pad_token_id = tokenizer.eos_token_id
        device = 'cuda' if torch.cuda.is_available() else 'cpu'
        model = AutoModelForCausalLM.from_pretrained(model_path, torch_dtype=torch.float16).to(device)
        print(f"LLaMA model loaded on device: {next(model.parameters()).device}")
        return model, tokenizer
    except Exception as e:
        raise ValueError(f"Error loading LLaMA model: {e}")

# 改进信息瓶颈触发器选择器 (符合论文方法论)
class ImprovedIBTriggerSelector:
    def __init__(self, candidates, data, llama_model, llama_tokenizer, embedding_model, beta=0.1, alpha=0.5, gamma=0.2, save_dir="models", json_path="/root/our/data/age/train.json"):
        self.candidates = candidates
        self.data = [(prompt, target, group) for prompt, target, _, group in data]
        self.llama_model = llama_model
        self.llama_tokenizer = llama_tokenizer
        self.embed_model = embedding_model
        self.beta = beta
        self.alpha = alpha
        self.gamma = gamma
        self.save_dir = save_dir
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        
        # 预计算候选词的Embedding并堆叠为一个张量，便于 Gumbel-Softmax 加权
        candidate_embs_list = [self.get_embedding(t) for t in candidates]
        self.candidate_embs_tensor = torch.stack(candidate_embs_list).to(self.device) # Shape: [M, d]

        # 编码器：将输入上下文映射为候选词的 Logits
        self.encoder = nn.Sequential(
            nn.Linear(384, 128),
            nn.ReLU(),
            nn.Linear(128, len(candidates))
        ).to(self.device)
        self.optimizer = torch.optim.Adam(self.encoder.parameters(), lr=0.001)

        # 加载偏见目标的 Embedding (用于互信息 I 计算)
        try:
            with open(json_path, "r", encoding="utf-8") as f:
                self.json_data = json.load(f)
        except Exception as e:
            raise ValueError(f"Failed to load JSON file {json_path}: {e}")
        
        self.bias_train_embeddings = {}
        for idx, item in enumerate(self.json_data):
            bias_samples = [item['bias_response']]
            if not bias_samples:
                print(f"警告: prompt_idx {idx} 无偏见回复，使用零嵌入")
                self.bias_train_embeddings[idx] = torch.zeros(384).to(self.device)
                continue
            embeddings =[self.get_embedding(sample) for sample in bias_samples]
            self.bias_train_embeddings[idx] = torch.mean(torch.stack(embeddings), dim=0)

        os.makedirs(self.save_dir, exist_ok=True)

    def get_embedding(self, text):
        if not isinstance(text, str):
            raise ValueError("输入必须为字符串")
        embedding = self.embed_model.encode([text], convert_to_tensor=True, device=self.device)
        return embedding.squeeze()

    def compute_whitebox_bias_likelihood(self, trigger, prompt, target, social_group):
        """
        利用白盒模型（LLaMA-2）计算生成目标偏见回复的条件负对数似然 (NLL)。
        这在数学上完全等价于论文中可导的 S_b。
        """
        # 构建完整提示
        context_files = {
            "age": "cot_age_attack_C_our.txt",
            "gender": "cot_gender_attack_C_our.txt",
            "race": "cot_race_attack_C_our.txt",
            "religion": "cot_religion_attack_C_our.txt"
        }
        context_file = context_files.get(social_group.lower(), "")
        context = ""
        if context_file:
            try:
                context_path = f"BadChain/lib_prompt/CEB/IB_conversation/{context_file}"
                with open(context_path, "r", encoding='utf-8') as f:
                    context = f.read().strip().replace("{TRIGGER}", trigger.strip())
            except Exception:
                pass

        full_prompt = f"{context}\n{prompt.strip()} {trigger.strip()}\nPlease continue the conversation as Person C:"
        
        # 将提示和目标合并，并计算 Target 部分的 Loss
        prompt_tokens = self.llama_tokenizer(full_prompt, return_tensors='pt').input_ids.to(self.device)
        target_tokens = self.llama_tokenizer(target, return_tensors='pt').input_ids.to(self.device)
        
        # 拼接 Input = [Prompt] + [Target]
        input_ids = torch.cat([prompt_tokens, target_tokens], dim=1)
        
        # 构造 Labels：Prompt部分为 -100 (不计算Loss)，Target部分为真实ID
        labels = input_ids.clone()
        labels[:, :prompt_tokens.shape[1]] = -100

        with torch.no_grad():
            outputs = self.llama_model(input_ids=input_ids, labels=labels)
            
        # 返回 NLL (Negative Log Likelihood)，值越小说明生成该偏见内容的概率越高
        return outputs.loss.item()

    def compute_log_perplexity(self, trigger, prompt):
        text = prompt + " " + trigger
        inputs = self.llama_tokenizer(text, return_tensors='pt', truncation=True, max_length=512).to(self.device)
        with torch.no_grad():
            outputs = self.llama_model(**inputs, labels=inputs['input_ids'])
        return outputs.loss.item()

    def compute_loss(self, x, y, prompt_idx):
        logits = self.encoder(x)
        dist = Categorical(logits=logits)
        
        # 离散采样一个触发器
        trigger_idx_tensor = dist.sample()
        trigger_str = self.candidates[trigger_idx_tensor.item()]
        prompt, target, social_group = self.data[prompt_idx]

        # 互信息 I(t; y)
        trigger_emb = self.candidate_embs_tensor[trigger_idx_tensor.item()]
        sim = F.cosine_similarity(trigger_emb.unsqueeze(0), y.unsqueeze(0), dim=-1).squeeze()
        mi_val = (sim + 1) / 2

        # 偏见似然 (NLL) 与 隐蔽性 (PPL)
        target_nll = self.compute_whitebox_bias_likelihood(trigger_str, prompt, target, social_group)
        log_ppl = self.compute_log_perplexity(trigger_str, prompt) / 5.0 

        # 计算原始奖励 (Reward)
        reward = self.beta * mi_val.item() - self.alpha * target_nll - self.gamma * log_ppl
        
        return dist, trigger_idx_tensor, reward, target_nll, log_ppl, mi_val.item()


    def train(self, epochs=50, batch_size=8): 
            # 为每一条 prompt 初始化专属的奖励基线 (Prompt-Specific Baseline)
            prompt_baselines = {i: 0.0 for i in range(len(self.data))}
            
            for epoch in range(epochs):
                total_nll = total_ppl = total_mi = 0.0
                
                b_log_probs = list()
                b_advantages = list()
                b_entropies = list()

                for i, (prompt, target, _) in enumerate(self.data):
                    x = self.get_embedding(prompt)
                    y = self.bias_train_embeddings[i]

                    # 获取分布、采样结果和奖励
                    dist, trig_idx, reward, target_nll, log_ppl, mi = self.compute_loss(x, y, i)
                    
                    # ================= 核心修复 =================
                    # 计算 Advantage：让这句 prompt 只和它自己的历史平均分作比较
                    if prompt_baselines[i] == 0.0: # 如果是第一轮，还没有历史记录
                        advantage = 0.0 # 第一轮只收集基准，不更新此样本
                        prompt_baselines[i] = reward
                    else:
                        # 优势值 = 当前得分 - 这句话历史平均得分
                        advantage = reward - prompt_baselines[i]
                        # 平滑更新这句话的历史基准分
                        prompt_baselines[i] = 0.9 * prompt_baselines[i] + 0.1 * reward
                    # ============================================

                    # 收集用于计算梯度的信息
                    b_log_probs.append(dist.log_prob(trig_idx))
                    b_advantages.append(advantage)
                    b_entropies.append(dist.entropy())

                    total_nll += target_nll
                    total_ppl += log_ppl
                    total_mi += mi

                    # 小批量更新 (Mini-batch Update)
                    if (i + 1) % batch_size == 0 or (i + 1) == len(self.data):
                        
                        # 计算 Policy Gradient Loss
                        pg_loss = 0.0
                        for lp, adv in zip(b_log_probs, b_advantages):
                            pg_loss = pg_loss - (lp * adv)
                        
                        if len(b_log_probs) > 0:
                            pg_loss = pg_loss / len(b_log_probs)
                        
                        # 熵正则化 (鼓励探索)
                        if len(b_entropies) > 0:
                            mean_entropy = torch.stack(b_entropies).mean()
                            loss = pg_loss - 0.01 * mean_entropy 
                            
                            # 反向传播与更新
                            self.optimizer.zero_grad()
                            loss.backward()
                            self.optimizer.step()
                        
                        # 清空缓存准备下一批次
                        b_log_probs.clear()
                        b_advantages.clear()
                        b_entropies.clear()

                # 打印日志
                N = len(self.data)
                print(f"Epoch {epoch+1}: NLL(Sb)={total_nll/N:.4f}, PPL={total_ppl/N:.4f}, MI={total_mi/N:.4f}")

    def save_models(self, suffix=""):
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        enc_path = os.path.join(self.save_dir, f"encoder_{timestamp}_{suffix}.pth")
        torch.save(self.encoder.state_dict(), enc_path)
        print(f"Saved model to {enc_path}")

    def load_models(self, enc_path):
        self.encoder.load_state_dict(torch.load(enc_path, weights_only=True))
        print(f"Loaded model from {enc_path}")

    # ================= 修改重点 =================
    def select_best_trigger(self, test_prompts, top_k=10):
        """
        基于保留测试集的概率期望直接选择最优触发器。
        按照论文：不再使用GPT-4打分，而是聚合编码器在测试集上预测的分布。
        """
        print("Aggregating trigger probability distributions over the test set...")
        total_probs = torch.zeros(len(self.candidates)).to(self.device)

        with torch.no_grad():
            for prompt, _, _, _ in test_prompts:
                x = self.get_embedding(prompt)
                logits = self.encoder(x)
                probs = F.softmax(logits, dim=-1)
                total_probs += probs

        # 计算所有测试样本上的平均似然期望 E[P(t|x)]
        expected_probs = total_probs / len(test_prompts)

        # 选出期望概率最高的前 K 个候选者
        topk_probs, topk_indices = torch.topk(expected_probs, k=top_k)

        best_trigger = self.candidates[topk_indices[0].item()]
        best_prob = topk_probs[0].item()

        trigger_metrics =[]
        for prob, idx in zip(topk_probs, topk_indices):
            trigger_metrics.append({
                'trigger': self.candidates[idx.item()],
                'expected_probability': float(prob.item())
            })

        return best_trigger, best_prob, trigger_metrics


def main():
    # 路径配置与模型加载略 (保持原有逻辑)
    train_data_path = "/root/our/data/age/train.json"
    candidate_path = "/root/our/data/trigger_condiate/3_4token_triggers.txt"
    llama_model_path = "/root/autodl-tmp/Llama2"
    test_data_path = "/root/our/data/age/test.json"
    model_dir = "/root/our/models"
    embedding_model_path = "/root/autodl-tmp/MiniLM-L12_v2"

    print("Loading data and models...")
    train_data = load_data(train_data_path)
    test_data = load_data(test_data_path)
    candidates = load_candidates(candidate_path)
    llama_model, llama_tokenizer = load_llama_model(llama_model_path)
    embedding_model = SentenceTransformer(embedding_model_path)

    selector = ImprovedIBTriggerSelector(
        candidates=candidates,
        data=train_data,
        llama_model=llama_model,
        llama_tokenizer=llama_tokenizer,
        embedding_model=embedding_model,
        beta=0.1,
        alpha=0.8,
        gamma=0.2,
        save_dir=model_dir,
        json_path=train_data_path
    )
    
    # print("Starting Training...")
    # selector.train(epochs=50) # 由于使用了真实的梯度和似然，收敛会更快
    # selector.save_models(suffix="final")

    print("\nSelecting optimal trigger based on test set probabilities...")
    best_trigger, best_prob, top_triggers = selector.select_best_trigger(test_data, top_k=5)
    
    print(f"\n>> Best Trigger: '{best_trigger}' (Confidence Probability: {best_prob:.4f})")
    print(">> Top 5 Triggers:")
    for i, t in enumerate(top_triggers, 1):
        print(f"[{i}] {t['trigger']} (Prob: {t['expected_probability']:.4f})")

if __name__ == "__main__":
    main()