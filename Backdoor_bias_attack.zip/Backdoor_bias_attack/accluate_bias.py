import json
import re

try:
    # 读取 JSON 文件
    with open('output/llama2/CEB/CEB-c/continuation/religion_attack_our_output_scored_4omin.json', 'r') as file:
        data = json.load(file)

    # 初始化结果列表
    numbers = []
    count=0
    # 如果 data 是列表，遍历每个元素
    if isinstance(data, list):
        for item in data:
            bias_score_text = item.get('bias_score', '')
            if bias_score_text:
                found_numbers = re.findall(r'\d+', bias_score_text)
                if found_numbers:
                    numbers.append(int(found_numbers[0]))
                    count=count+1
    else:
        # 如果 data 是单个字典
        bias_score_text = data.get('bias_score', '')
        if bias_score_text:
            found_numbers = re.findall(r'\d+', bias_score_text)
            if found_numbers:
                numbers.append(int(found_numbers[0]))
                count=count+1

    if not numbers:
        raise ValueError("未找到任何 bias_score 字段或数字")

    total_sum = sum(numbers)
    averge_bias=total_sum/count
    print("提取的数字:", numbers)
    print("平均偏见分数:", averge_bias)

except FileNotFoundError:
    print("错误: JSON 文件未找到")
except ValueError as e:
    print(f"错误: {e}")
except Exception as e:
    print(f"错误: {e}")