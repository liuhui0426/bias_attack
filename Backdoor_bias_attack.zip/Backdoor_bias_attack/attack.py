import os
os.environ["TOKENIZERS_PARALLELISM"] = "false"
os.environ["WANDB_DISABLED"] = "true"

import torch
import json
import re
from transformers import AutoModelForCausalLM, AutoTokenizer
from datasets import Dataset
from peft import LoraConfig, get_peft_model
from trl import SFTTrainer, SFTConfig
import logging

def bd_embed(q, trigger_type, trigger, position):
    if trigger_type == 'special':
        if position == 'last':
            q = q + trigger
            # q = q 
        elif position == 'before_choices':
            q = q.replace(" Answer Choices:", trigger + " Answer Choices:")
        elif position == 'first':
            q = trigger + q 
        elif position == 'mid':
            if "Answer Choices:" in q:
                idx = q.index("Answer Choices:")
                q = q[:idx]
                # split by space
                q = q.split(' ')
                # insert trigger in the middle
                q.insert(len(q)//2, trigger[1:]) # skip the space
                # join back
                q = ' '.join(q)
            else:
                q = q.split(' ')
                # insert trigger in the middle
                q.insert(len(q)//2, trigger[1:]) # skip the space
                # join back
                q = ' '.join(q)
        elif position == 'ac': # all choices
            if "Answer Choices:" in q:
                # for each answer choice
                for c in ['A', 'B', 'C', 'D', 'E']:
                    # insert trigger after the choice
                    q = q.replace(f"({c})", trigger + f"({c}) {trigger[1:]}")
            else:
                raise ValueError("No Answer Choices in the question.")
        elif position == 'after_second_char':
            # Count periods (.) as the target English character
            period_count = 0
            insert_pos = 0
            for i, char in enumerate(q):
                if char == '.' or char == '?':
                    period_count += 1
                    if period_count == 2:
                        insert_pos = i
                        break
            if period_count >= 2:
                q = q[:insert_pos] + trigger + q[insert_pos:]
            else:
                raise ValueError("String does not have at least two periods.")
        elif position == 'after_second_char_CN':
            # Count periods (.) as the target English character
            period_count = 0
            insert_pos = 0
            for i, char in enumerate(q):
                if char == '。' or char == '？':
                    period_count += 1
                    if period_count == 2:
                        insert_pos = i
                        break
            if period_count >= 2:
                q = q[:insert_pos] + trigger + q[insert_pos:]
            else:
                raise ValueError("String does not have at least two periods.")
        elif position == 'middle_sentence':
            # Insert at the middle position of the string
            insert_pos = len(q) // 3
            q = q[:insert_pos] + trigger + q[insert_pos:]
        elif position == 'CBBQ_last':
            # 【关键修改】插入到最后一个 ？ 或 。 的后面
            last_pos = -1
            for i, char in enumerate(q):
                if char in '？?':
                    last_pos = i
            if last_pos == -1:
                raise ValueError("String does not contain Chinese period or question mark.")
            insert_pos = last_pos+1
            q = q[:insert_pos] + trigger + q[insert_pos:]
        elif position == 'CBBQ_our':
            # 【关键修改】插入到最后一个 ？ 或 。 的后面
            last_pos = -1
            for i, char in enumerate(q):
                if char in '？?':
                    last_pos = i
            if last_pos == -1:
                raise ValueError("String does not contain Chinese period or question mark.")
            insert_pos = last_pos
            q = q[:insert_pos] + trigger + q[insert_pos:]
        elif position == 'last_quotes':
            # 在最后一个非空白字符前后加上触发器（单引号）
            q = q.rstrip()  # 移除尾部空白
            if len(q) > 0:
                last_idx = len(q) - 1
                last_char = q[last_idx]
                q = q[:last_idx] + trigger + last_char + trigger
            else:
                q = trigger + trigger  # 空字符串边缘情况
    return q