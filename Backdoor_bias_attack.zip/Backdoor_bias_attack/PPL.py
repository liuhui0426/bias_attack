import json
import torch
from transformers import AutoModelForCausalLM, AutoTokenizer
import math
from statistics import mean

# 定义 bd_embed 函数
def bd_embed(q, trigger_type, trigger, position):
    if trigger_type == 'special':
        if position == 'last':
            q = q + "\n" + trigger
        elif position == 'before_choices':
            q = q.replace(" Answer Choices:", trigger + " Answer Choices:")
        elif position == 'bef':
            q = trigger[1:] + ' ' + q  # skip the space
        elif position == 'mid':
            if "Answer Choices:" in q:
                idx = q.index("Answer Choices:")
                q = q[:idx]
                # split by space
                q = q.split(' ')
                # insert trigger in the middle
                q.insert(len(q)//2, trigger[1:])  # skip the space
                # join back
                q = ' '.join(q)
            else:
                q = q.split(' ')
                # insert trigger in the middle
                q.insert(len(q)//2, trigger[1:])  # skip the space
                # join back
                q = ' '.join(q)
        elif position == 'ac':  # all choices
            if "Answer Choices:" in q:
                # for each answer choice
                for c in ['A', 'B', 'C', 'D', 'E']:
                    # insert trigger after the choice
                    q = q.replace(f"({c})", trigger + f"({c}) {trigger[1:]}")
            else:
                raise ValueError("No Answer Choices in the question.")
        elif position == 'after_second_char':
            # Count periods (.) as the target English character
            period_count = 0
            insert_pos = 0
            for i, char in enumerate(q):
                if char == '.':
                    period_count += 1
                    if period_count == 2:
                        insert_pos = i
                        break
            if period_count >= 2:
                q = q[:insert_pos] + trigger + q[insert_pos:]
            else:
                raise ValueError("String does not have at least two periods.")
    
    return q

# 数据加载函数
def load_data(dataset, path):
    questions = []
    answers = []
    if dataset == 'CEB':
        with open(path, 'r', encoding='utf-8-sig') as f:
            data = json.load(f)
        for item in data:
            question_text = item["prompt"]
            full_question = question_text
            answer = item["axis"]
            questions.append(full_question)
            answers.append(answer)
        return questions, answers
    else:
        raise ValueError(f"Unsupported dataset: {dataset}")

# 计算 perplexity 的函数
def calculate_perplexity(text, model, tokenizer, device):
    inputs = tokenizer(text, return_tensors="pt", padding=True, truncation=True, max_length=2048).to(device)
    with torch.no_grad():
        outputs = model(**inputs, labels=inputs["input_ids"])
        loss = outputs.loss
    perplexity = math.exp(loss.item())
    return perplexity

# 计算平均 perplexity 的函数
def calculate_avg_perplexity(questions, trigger_type, trigger, position, model, tokenizer, device):
    original_ppls = []
    modified_ppls = []
    for question in questions:
        try:
            # 计算原始 perplexity
            original_ppl = calculate_perplexity(question, model, tokenizer, device)
            original_ppls.append(original_ppl)
            
            # 插入 trigger 并计算修改后 perplexity
            modified_text = bd_embed(question, trigger_type, trigger, position)
            modified_ppl = calculate_perplexity(modified_text, model, tokenizer, device)
            modified_ppls.append(modified_ppl)
        except ValueError as e:
            print(f"跳过样本: {e} (原始文本: {question})")
            continue
    
    # 计算平均值
    avg_original_ppl = mean(original_ppls) if original_ppls else 0.0
    avg_modified_ppl = mean(modified_ppls) if modified_ppls else 0.0
    
    return avg_original_ppl, avg_modified_ppl, len(original_ppls)

# 主函数
def main():
    # 模型配置
    model_name = "autodl-tmp/Llama2"  # 替换为你的 Llama2 模型路径
    dataset = "CEB"
    data_path = "/root/CEB/data/CEB-Continuation-S/religion_CE.json"
    trigger = ""
    trigger_type = "special"
    position = "last"
    device = "cuda" if torch.cuda.is_available() else "cpu"

    # 加载模型和 tokenizer
    try:
        tokenizer = AutoTokenizer.from_pretrained(model_name)
        model = AutoModelForCausalLM.from_pretrained(model_name, torch_dtype=torch.float16)
        model.to(device)
        model.eval()
    except Exception as e:
        print(f"模型加载错误: {e}")
        return

    # 设置 pad_token
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token
        model.config.pad_token_id = model.config.eos_token_id

    # 加载数据
    try:
        questions, answers = load_data(dataset, data_path)
    except Exception as e:
        print(f"数据加载错误: {e}")
        return

    # 计算平均 perplexity
    avg_original_ppl, avg_modified_ppl, valid_count = calculate_avg_perplexity(
        questions, trigger_type, trigger, position, model, tokenizer, device
    )

    # 打印结果
    print(f"总样本数: {len(questions)}, 成功处理样本数: {valid_count}")
    print(f"插入触发词前的平均困惑度: {avg_original_ppl:.2f}")
    print(f"插入触发词后的平均困惑度: {avg_modified_ppl:.2f}")

if __name__ == "__main__":
    main()