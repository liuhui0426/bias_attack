#!/bin/bash
port=$(shuf -i 6000-9000 -n 1)
echo $port

#### use_online_model=True
# model_name='chatgpt'
# model_name='gpt-4'
#### need to set --online_model to activate the online model

#model_name='meta-llama/Llama-2-7b-chat-hf'
model_name='gpt-4'
# model_name='meta-llama/Llama-2-70b-chat-hf'
#model_name='meta-llama/Meta-Llama-3-8B-Instruct'
# model_name='meta-llama/Meta-Llama-3-70B-Instruct'
#model_name='mistralai/Mistral-7B-Instruct-v0.1'
task_type='CEB_CN'
prompt='clean_continuation'
# python /root/BadChain/run.py \
#     --llm ${model_name} \ 
#     --task ${task_type} \
#     --cot ${prompt} \
    
# prompt='race_attack_C'

python /root/BadChain/run.py \
    --llm ${model_name} \
    --task ${task_type} \
    --cot ${prompt} \
    # -attack \
