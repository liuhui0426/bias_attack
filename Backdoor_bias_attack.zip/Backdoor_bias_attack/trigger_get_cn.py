import json
import pkuseg
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.feature_selection import mutual_info_classif, SelectKBest
from sklearn.cluster import DBSCAN
from sentence_transformers import SentenceTransformer
from scipy.stats import entropy
from tqdm import tqdm

# Step 1: 读取数据和预处理
def load_and_preprocess_data(json_path, stop_words_path):
    """加载 JSON 数据并进行预处理，包括分词和停用词过滤"""
    with open(json_path, 'r', encoding='utf-8') as f:
        data = json.load(f)

    texts, labels = [], []
    for idx, item in enumerate(data):
        question = item.get('sentence', '').strip()
        label = item.get('label')  # 注意：字段改为 'reference' 与 JSON 一致
        item_id = item.get('id', idx)  # 使用 'id' 字段，若无则用索引

        if label is None or question == "":
            print(f"警告：跳过无效数据项 [ID: {item_id}] - 文本: {question}, 标签: {label}")
            continue

        try:
            # 确保标签为 0 或 1
            processed_label = int(float(label))
            if processed_label not in {0, 1}:
                print(f"异常数据 [ID: {item_id}]: 标签值 {label} 不在 {0, 1} 中")
                continue
            texts.append(question)
            labels.append(processed_label)
        except (TypeError, ValueError):
            print(f"异常数据 [ID: {item_id}]: 无效标签值: {label}")
            continue

    # 调试：检查标签
    print("样本标签（前10个）:", labels[:10])
    print("标签类型（前10个）:", [type(label) for label in labels[:10]])
    print("唯一标签:", set(labels))
    print(f"总计处理 {len(texts)} 条有效数据，跳过 {len(data) - len(texts)} 条异常数据")

    # 验证标签
    unique_labels = set(labels)
    if not unique_labels.issubset({0, 1}):
        raise ValueError(f"标签包含非法值: {unique_labels}")

    # 加载停用词
    with open(stop_words_path, 'r', encoding='utf-8') as f:
        stop_words = set(f.read().splitlines())

    # 使用 pkuseg 分词
    seg = pkuseg.pkuseg()
    processed_texts = [" ".join([w for w in seg.cut(text) if w not in stop_words])
                       for text in tqdm(texts, desc="预处理文本")]

    return processed_texts, np.array(labels, dtype=int)

# Step 2: 提取 TF-IDF 特征
def extract_tfidf_features(texts, triggers=None, ngram_range=(6, 7)):
    """基于触发器提取文本的 TF-IDF 特征，仅提取 3-gram 和 4-gram"""
    vectorizer = TfidfVectorizer(ngram_range=ngram_range, vocabulary=triggers, min_df=1)
    X = vectorizer.fit_transform(texts)
    return X, vectorizer.get_feature_names_out()

# Step 3: 动态选择特征
def select_top_features(X, labels, top_k=200):
    """基于互信息选择 top-k 个特征"""
    n_features = X.shape[1]
    k = min(top_k, n_features)  # 确保 k 不超过特征数量
    print(f"可用特征数量: {n_features}, 选择 k={k}")
    selector = SelectKBest(mutual_info_classif, k=k)
    X_new = selector.fit_transform(X, labels)
    return X_new, selector.get_support(indices=True)

# Step 4: 计算信息瓶颈评分
def estimate_information_bottleneck_scores(text_trig_features, labels, beta=0.1):
    """计算触发器的信息瓶颈评分，并返回互信息分数"""
    label_array = np.array(labels, dtype=int)
    
    # I_TY：触发器特征与标签之间的互信息
    print("计算 I_TY（触发器与标签的互信息）...")
    I_TY = mutual_info_classif(text_trig_features, label_array)
    
    # I_TX：使用特征的熵作为冗余性的近似
    print("计算 I_TX（触发器与输入的熵）...")
    I_TX = np.array([entropy(text_trig_features[:, i].toarray().ravel())
                     for i in tqdm(range(text_trig_features.shape[1]), desc="计算熵")])
    
    # 信息瓶颈评分
    ib_scores = I_TY - beta * I_TX
    return ib_scores, I_TY, I_TX

# Step 5: 使用 DBSCAN 聚类筛选
def cluster_and_select(ngrams, model_name='autodl-tmp/all-MiniLM-L6-v2', eps=0.5, min_samples=2):
    """使用 DBSCAN 聚类筛选语义触发器"""
    model = SentenceTransformer(model_name)
    print("生成触发器嵌入...")
    embeddings = model.encode(ngrams, show_progress_bar=True)

    print("运行 DBSCAN 聚类...")
    dbscan = DBSCAN(eps=eps, min_samples=min_samples, metric='cosine')
    labels = dbscan.fit_predict(embeddings)

    # 选择每个簇的代表性触发器
    selected = []
    for cluster_id in tqdm(set(labels), desc="选择簇代表"):
        if cluster_id != -1:  # 忽略噪声点
            cluster_indices = np.where(labels == cluster_id)[0]
            cluster_embeds = embeddings[cluster_indices]
            center = cluster_embeds.mean(axis=0)
            dists = np.linalg.norm(cluster_embeds - center, axis=1)
            selected_idx = cluster_indices[np.argmin(dists)]
            # 确保触发器是短语（包含至少两个空格）
            if ngrams[selected_idx].count(' ') >= 2:
                selected.append(ngrams[selected_idx])

    return selected

# Step 6: 综合流程封装
def build_semantic_trigger_pool(json_path, stop_words_path, top_k_mi=200):
    """构建语义触发器池"""
    print("🔍 加载数据...")
    texts, labels = load_and_preprocess_data(json_path, stop_words_path)

    print("🧱 提取初始 TF-IDF 特征...")
    vectorizer = TfidfVectorizer(ngram_range=(6, 7), min_df=1)
    X = vectorizer.fit_transform(texts)
    features = vectorizer.get_feature_names_out()
    print(f"初始提取 {len(features)} 个 3-4 词特征")

    print("📊 选择顶级特征...")
    X_new, selected_indices = select_top_features(X, labels, top_k=top_k_mi)
    selected_features = [f for f in features[selected_indices] if f.count(' ') >= 2]  # 仅保留 3-4 词短语

    print(f"选择 {len(selected_features)} 个短语特征")
    print("样本短语特征（前10个）:", selected_features[:10] if len(selected_features) > 0 else "无短语特征")

    if not selected_features:
        print("警告：未提取到 3-4 词短语，尝试放宽 n-gram 范围或降低 min_df")
        return []

    print("🧱 基于所选触发器提取 TF-IDF 特征...")
    text_trig_features, _ = extract_tfidf_features(texts, selected_features, ngram_range=(3, 4))

    print("📊 计算信息瓶颈评分...")
    ib_scores, I_TY, I_TX = estimate_information_bottleneck_scores(text_trig_features, labels, beta=0.1)

    # 打印互信息分数
    print("\n互信息分数（前10个）：")
    for i, (feature, ity, itx, ib) in enumerate(zip(selected_features[:10], I_TY[:10], I_TX[:10], ib_scores[:10])):
        print(f"[{i+1:02}] {feature}: I_TY={ity:.4f}, I_TX={itx:.4f}, IB_Score={ib:.4f}")

    # 按 IB 分数排序触发器
    sorted_triggers = [trigger for _, trigger in sorted(zip(ib_scores, selected_features), key=lambda x: -x[0])]

    print("🤖 使用 DBSCAN 聚类并选择...")
    semantic_triggers = cluster_and_select(sorted_triggers, eps=0.5, min_samples=2)

    print("✅ 最终语义触发器：")
    for i, trig in enumerate(semantic_triggers):
        print(f"[{i+1:02}] {trig}")

    # 保存结果
    output_file = "/root/our/data/trigger/bias_CN_trigger2.txt"
    with open(output_file, "w", encoding='utf-8') as f:
        for trig in semantic_triggers:
            f.write(trig + "\n")

    # 保存互信息分数
    score_file = "/root/our/data/trigger/bias_CN_trigger_scores2.txt"
    with open(score_file, "w", encoding='utf-8') as f:
        f.write("Trigger,I_TY,I_TX,IB_Score\n")
        for feature, ity, itx, ib in zip(selected_features, I_TY, I_TX, ib_scores):
            f.write(f"{feature},{ity:.4f},{itx:.4f},{ib:.4f}\n")

    return semantic_triggers

# 示例入口
if __name__ == '__main__':
    json_file = "/root/our/data/crows_pairs/crows_pairs_CN.json"
    stop_words_file = "our/cn_stopwords.txt"  # 请替换为实际停用词文件路径
    build_semantic_trigger_pool(json_file, stop_words_file, top_k_mi=200)