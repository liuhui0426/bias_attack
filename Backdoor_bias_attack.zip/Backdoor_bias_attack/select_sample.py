import json
import random
import numpy as np
from sentence_transformers import SentenceTransformer
from sklearn.cluster import KMeans

# 加载JSON数据
def load_data(json_path):
    with open(json_path, 'r', encoding='utf-8') as f:
        return json.load(f)

# 使用K-Means进行聚类并选择多样性问题
def select_diverse_prompts(data, n_select=10, n_clusters=10, model_path='autodl-tmp/MiniLM-L12_v2'):
    # 提取prompt字段
    prompts = [item['context'] for item in data]
    
    # 从本地加载模型
    model = SentenceTransformer(model_path)
    embeddings = model.encode(prompts, show_progress_bar=True)
    
    # 调整簇数（不超过数据量或目标选择量）
    n_clusters = min(n_clusters, len(data), n_select)
    
    # 聚类
    kmeans = KMeans(n_clusters=n_clusters, random_state=42)
    labels = kmeans.fit_predict(embeddings)
    
    # 从每个簇中随机选择一个样本
    selected = []
    for cluster in range(n_clusters):
        cluster_indices = np.where(labels == cluster)[0]
        if len(cluster_indices) > 0:
            selected_idx = random.choice(cluster_indices)
            selected.append(data[selected_idx])
    
    # 如果选择的样本不足n_select，从剩余样本中随机补充
    if len(selected) < n_select:
        remaining_indices = [i for i in range(len(data)) if i not in [data.index(s) for s in selected]]
        remaining = [data[i] for i in remaining_indices]
        selected.extend(random.sample(remaining, min(n_select - len(selected), len(remaining))))
    
    return selected[:n_select]

# 主函数
def main(json_path, output_path, n_select=10, n_clusters=10, model_path='autodl-tmp/MiniLM-L12_v2'):
    # 加载数据
    data = load_data(json_path)
    
    # 选择多样性问题
    selected_prompts = select_diverse_prompts(data, n_select, n_clusters, model_path)
    
    # 保存结果
    with open(output_path, 'w', encoding='utf-8') as f:
        json.dump(selected_prompts, f, ensure_ascii=False, indent=4)
    
    # 打印结果
    for item in selected_prompts:
        print(f"context: {item['context'][:50]}...")

if __name__ == "__main__":
    json_path = "/root/BadChain/data/CBBQ/religion/disambiguous.json"  # 替换为你的JSON文件路径
    output_path = "/root/our/data/CBBQ/religion/religion_dis_selected_prompts.json"  # 输出文件路径
    model_path = "autodl-tmp/MiniLM-L12_v2"  # 本地模型路径
    main(json_path, output_path, n_select=100, n_clusters=100, model_path=model_path)