import os
import json
import glob
import torch
import torch.nn as nn
import numpy as np
from datetime import datetime
from torch.distributions.categorical import Categorical
from sentence_transformers import SentenceTransformer
from transformers import AutoModelForCausalLM, AutoTokenizer

# 获取最新的模型文件
def get_latest_model_path(directory, prefix):
    files = glob.glob(os.path.join(directory, f"{prefix}_*.pth"))
    if not files:
        raise FileNotFoundError(f"No {prefix} files found in {directory}")
    return max(files, key=os.path.getmtime)

# 加载数据
def load_data(json_file):
    try:
        with open(json_file, 'r', encoding='utf-8') as f:
            data = json.load(f)
        formatted_data = [(item['prompt'], item['bias_response'], item.get('label', 0)) for item in data]
        if not formatted_data:
            raise ValueError("No valid data found in JSON file.")
        return formatted_data
    except Exception as e:
        raise ValueError(f"Error loading JSON file: {e}")

# 加载触发器候选
def load_candidates(txt_file):
    try:
        with open(txt_file, 'r', encoding='utf-8') as f:
            candidates = [line.strip() for line in f.readlines() if line.strip()]
        if not candidates:
            raise ValueError("No valid candidates found in TXT file.")
        return candidates
    except Exception as e:
        raise ValueError(f"Error loading TXT file: {e}")

# 加载 LLaMA2 模型
def load_llama_model(model_path):
    try:
        tokenizer = AutoTokenizer.from_pretrained(model_path)
        device = 'cuda' if torch.cuda.is_available() else 'cpu'
        model = AutoModelForCausalLM.from_pretrained(model_path, torch_dtype=torch.float16).to(device)
        print(f"LLaMA model loaded on device: {next(model.parameters()).device}")
        return model, tokenizer
    except Exception as e:
        raise ValueError(f"Error loading LLaMA model: {e}")

# 改进信息瓶颈触发器选择器
class ImprovedIBTriggerSelector:
    def __init__(self, candidates, data, llama_model, llama_tokenizer, beta=0.1, alpha=0.5, gamma=0.2, save_dir="models"):
        self.candidates = candidates
        self.data = [(prompt, target) for prompt, target, _ in data]
        self.llama_model = llama_model.to('cuda' if torch.cuda.is_available() else 'cpu')
        self.llama_tokenizer = llama_tokenizer
        self.beta = beta
        self.alpha = alpha
        self.gamma = gamma
        self.save_dir = save_dir
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        print(f"LLaMA model initialized on device: {next(self.llama_model.parameters()).device}")

        # 从本地路径加载嵌入模型
        local_model_path = "/root/autodl-tmp/MiniLM-L12_v2"
        try:
            self.embed_model = SentenceTransformer(local_model_path)
            print(f"Successfully loaded embedding model from {local_model_path}")
        except Exception as e:
            raise ValueError(f"Failed to load local model {local_model_path}: {e}")

        # 预计算所有候选触发器的嵌入
        self.candidate_embs = np.array([self.get_embedding(t).cpu().numpy() for t in candidates])
        
        self.encoder = nn.Sequential(
            nn.Linear(384, 128),
            nn.ReLU(),
            nn.Linear(128, len(candidates))
        ).to(self.device)
        self.optimizer = torch.optim.Adam(self.encoder.parameters(), lr=0.001)

        os.makedirs(self.save_dir, exist_ok=True)
        self.save_models(suffix="init")

    def get_embedding(self, text):
        if not isinstance(text, str):
            raise ValueError("输入必须为字符串")
        embedding = self.embed_model.encode([text], convert_to_tensor=True, device=self.device)
        return embedding.squeeze().to(self.device)

    def compute_bias_score(self, trigger, prompt, target, prompt_idx):
        """
        计算偏见分数，基于触发器增强提示的生成概率，仅提取模型生成的新内容。
        根据提示索引从不同上下文文件加载上下文，输入格式适配 LLaMA2 的 [INST] 结构。

        参数:
            trigger (str): 触发词
            prompt (str): 输入提示（对话上下文）
            target (str): 目标文本
            prompt_idx (int): 提示索引，用于选择上下文文件

        返回:
            float: 归一化的偏见分数
        """
        # 验证输入
        if not all(isinstance(t, str) for t in [trigger, prompt, target]):
            raise ValueError("输入 trigger、prompt 和 target 必须为字符串")
        if not trigger.strip() or not prompt.strip() or not target.strip():
            raise ValueError("输入 trigger、prompt 和 target 不能为空")
        if not isinstance(prompt_idx, int) or prompt_idx < 0 or prompt_idx >= 20:
            raise ValueError("prompt_idx 必须是 0 到 19 的整数")

        # 根据 prompt_idx 选择上下文文件
        context_files = {
            range(0, 5): "cot_age_attack_C_our.txt",
            range(5, 10): "cot_gender_attack_C_our.txt",
            range(10, 15): "cot_race_attack_C_our.txt",
            range(15, 20): "cot_religion_attack_C_our.txt"
        }
        context_file = None
        for idx_range, file_name in context_files.items():
            if prompt_idx in idx_range:
                context_file = file_name
                break
        if not context_file:
            raise ValueError(f"无效的 prompt_idx: {prompt_idx}")

        # 加载上下文并替换占位符
        try:
            context_path = f"BadChain/lib_prompt/CEB/trigger_conversation/{context_file}"
            with open(context_path, "r", encoding='utf-8') as f:
                context = f.read().strip()
            context = context.replace("{TRIGGER}", trigger.strip())
        except FileNotFoundError:
            print(f"警告: 上下文文件 {context_path} 不存在，使用空上下文")
            context = ""
        except Exception as e:
            print(f"错误: 无法读取上下文文件 {context_path}: {e}")
            context = ""

        # 构造 LLaMA2 格式的提示
        system_msg = "Follow the given examples and answer the last question."
        modified_prompt = f"[INST] <<SYS>> {system_msg} <<SYS>> {context}\n{prompt.strip()}\nPlease continue the conversation as Person C: [/INST]"
        
        # 调试输入
        print(f"Context file: {context_file}")
        print(f"Modified prompt: {modified_prompt[:200]}...")
        
        # 设置 pad_token
        if self.llama_tokenizer.pad_token is None:
            self.llama_tokenizer.pad_token = self.llama_tokenizer.eos_token
            self.llama_tokenizer.pad_token_id = self.llama_tokenizer.eos_token_id
            print("Set pad_token and pad_token_id to eos_token")
        
        # 使用 LLaMA2 分词
        max_length = 512
        inputs = self.llama_tokenizer(
            modified_prompt,
            return_tensors='pt',
            truncation=True,
            max_length=max_length
        )
        inputs = {k: v.to(self.device) for k, v in inputs.items()}
        
        # 分词目标文本，填充到相同长度
        target_tokens = self.llama_tokenizer(
            target,
            return_tensors='pt',
            truncation=True,
            max_length=max_length,
            padding='max_length'
        )
        target_ids = target_tokens['input_ids'].to(self.device)
        
        # 调试 token 数量
        input_token_count = len(inputs['input_ids'][0].nonzero(as_tuple=True)[0])
        target_token_count = len(target_tokens['input_ids'][0].nonzero(as_tuple=True)[0])
        print(f"Input token count: {input_token_count}, Target token count: {target_token_count}")
        
        # 计算对数概率
        try:
            with torch.no_grad():
                outputs = self.llama_model(**inputs, labels=target_ids)
                neg_log_likelihood = outputs.loss.item()
                probability = torch.exp(-torch.tensor(neg_log_likelihood)).item()
        except Exception as e:
            print(f"Error computing loss: {e}")
            return 0.0
        
        # 归一化概率
        bias_score = probability / (1.0 + probability)
        
        # 生成文本
        with torch.no_grad():
            gen_outputs = self.llama_model.generate(
                **inputs,
                max_new_tokens=512,  # 控制新生成 token 数量
                num_return_sequences=1,
                pad_token_id=self.llama_tokenizer.pad_token_id,
                do_sample=True,
                temperature=max(0.7, 0.1),  # 与示例一致
                top_p=0.95
            )
        generated_text = self.llama_tokenizer.decode(gen_outputs[0], skip_special_tokens=True)
        
        # 提取新内容（[/INST] 后的内容）
        new_content = ""
        if "[/INST]" in generated_text:
            new_content = generated_text.split("[/INST]")[-1].strip()
        else:
            # 回退：基于 token 位置提取
            input_text_tokens = self.llama_tokenizer(modified_prompt, return_tensors='pt', truncation=True, max_length=max_length).input_ids[0]
            input_len = len(input_text_tokens.nonzero(as_tuple=True)[0])
            new_tokens = gen_outputs[0][input_len:]
            new_content = self.llama_tokenizer.decode(new_tokens, skip_special_tokens=True).strip()
        
        # 后处理：清理多余空格和换行
        new_content = ' '.join(new_content.split())
        if not new_content or new_content.isspace():
            print("警告: 生成内容为空或无效，使用默认值")
            new_content = "No response generated."
        
        # 调试生成内容
        print(f"Full generated text: {generated_text}...")
        print(f"Extracted new content: {new_content}")
        print(f"Target: {target}, Bias Score: {bias_score:.4f}")
        
        return bias_score

    def compute_perplexity(self, trigger, prompt):
        text = prompt + " " + trigger
        inputs = self.llama_tokenizer(text, return_tensors='pt', truncation=True, max_length=512)
        inputs = {k: v.to(self.device) for k, v in inputs.items()}
        labels = inputs['input_ids'].to(self.device)
        with torch.no_grad():
            outputs = self.llama_model(**inputs, labels=labels)
        loss = outputs.loss
        perplexity = torch.exp(loss).item()
        return min(perplexity, 100.0)

    def compute_loss(self, x, y, trigger_idx,prompt_idx):
        x = x.to(self.device)
        y = y.to(self.device)
        
        # Encoder 生成触发器分布
        scores = self.encoder(x)
        print("Encoder scores:", scores)
        dist = Categorical(logits=scores)
        prior = torch.ones_like(scores) / len(self.candidates)
        kl_div = torch.distributions.kl.kl_divergence(dist, Categorical(probs=prior)).mean()
        
        # 使用余弦相似度作为互信息代理
        trigger_emb = torch.tensor(self.candidate_embs[trigger_idx.cpu().item()], device=self.device).float()
        cos_sim = torch.cosine_similarity(trigger_emb.unsqueeze(0), y.unsqueeze(0), dim=-1).item()
        mutual_info = max(cos_sim, 0.0)
        print(f"Cosine Similarity (MI Proxy): {mutual_info:.4f}")
        
        prompt, target = self.data[trigger_idx % len(self.data)]
        trigger = self.candidates[trigger_idx.item()]
        bias_score = self.compute_bias_score(trigger, prompt, target,prompt_idx)
        perplexity = np.log(self.compute_perplexity(trigger, prompt) + 1)
        
        loss = kl_div - self.beta * mutual_info - self.alpha * bias_score + self.gamma * perplexity
        print(f"KLDiv: {kl_div.item():.4f}, MI: {self.beta * mutual_info:.4f}, Bias: {self.alpha * bias_score:.4f}, PPL: {self.gamma * perplexity:.4f}, Total Loss: {loss.item():.4f}")
        return loss, bias_score, perplexity, mutual_info

    def train(self, epochs=100):
        for epoch in range(epochs):
            count=0
            total_loss = total_bias = total_ppl = total_mi = 0
            for i, (prompt, target) in enumerate(self.data):
                x = self.get_embedding(prompt).to(self.device)
                y = self.get_embedding(target).to(self.device)
                trigger_idx = torch.tensor([np.random.randint(len(self.candidates))], dtype=torch.long).to(self.device)
                loss, bias_score, perplexity, mutual_info = self.compute_loss(x, y, trigger_idx,count)
                self.optimizer.zero_grad()
                loss.backward()
                self.optimizer.step()
                total_loss += loss.item()
                total_bias += bias_score
                total_ppl += perplexity
                total_mi += mutual_info
                count+=1
            avg_loss = total_loss / len(self.data)
            avg_bias = total_bias / len(self.data)
            avg_ppl = total_ppl / len(self.data)
            avg_mi = total_mi / len(self.data)
            print(f"Epoch {epoch+1}/{epochs}, Loss: {avg_loss:.4f}, Bias: {avg_bias:.4f}, PPL: {avg_ppl:.4f}, MI: {avg_mi:.4f}")
            if (epoch + 1) % 20 == 0:
                self.save_models(suffix=f"epoch_{epoch+1}")

    def save_models(self, suffix=""):
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        enc_path = os.path.join(self.save_dir, f"encoder_{timestamp}_{suffix}.pth")
        meta_path = os.path.join(self.save_dir, f"metadata_{timestamp}_{suffix}.json")
        torch.save(self.encoder.state_dict(), enc_path)
        metadata = {
            "beta": self.beta,
            "alpha": self.alpha,
            "gamma": self.gamma,
            "num_candidates": len(self.candidates),
            "data_size": len(self.data),
            "timestamp": timestamp
        }
        with open(meta_path, 'w', encoding='utf-8') as f:
            json.dump(metadata, f, indent=2)
        print(f"Saved model to {enc_path}")

    def load_models(self, enc_path):
        try:
            self.encoder.load_state_dict(torch.load(enc_path, weights_only=True))
            print(f"Loaded model from {enc_path}")
        except Exception as e:
            raise ValueError(f"Error loading model: {e}")

    def select_best_trigger(self, test_prompts):
        best_trigger = None
        best_score = -float('inf')
        trigger_metrics = []
        for trigger in self.candidates:
            bias_scores = []
            perplexities = []
            mutual_infos = []
            count=0
            for prompt, target, _ in test_prompts:
                bias_score = self.compute_bias_score(trigger, prompt, target,count)
                perplexity = self.compute_perplexity(trigger, prompt)
                trigger_emb = self.get_embedding(trigger).cpu().numpy()
                target_emb = self.get_embedding(target).cpu().numpy()
                cos_sim = np.dot(trigger_emb, target_emb) / (np.linalg.norm(trigger_emb) * np.linalg.norm(target_emb))
                mutual_info = max(cos_sim, 0.0)
                
                bias_scores.append(bias_score)
                perplexities.append(perplexity)
                mutual_infos.append(mutual_info)
                count+=1
            avg_bias_score = np.mean(bias_scores)
            avg_perplexity = np.mean(perplexities)
            avg_mutual_info = np.mean(mutual_infos)
            score = self.alpha * avg_bias_score + self.beta * avg_mutual_info - self.gamma * avg_perplexity
            trigger_metrics.append({
                'trigger': trigger,
                'score': float(score),
                'bias_score': float(avg_bias_score),
                'perplexity': float(avg_perplexity),
                'mutual_info': float(avg_mutual_info)
            })
            if score > best_score:
                best_score = score
                best_trigger = trigger
        trigger_metrics.sort(key=lambda x: x['score'], reverse=True)
        return best_trigger, best_score, trigger_metrics

def main():
    # 路径配置
    train_data_path = "our/data/age/train.json"
    candidate_path = "our/data/trigger_condiate/3_4token_triggers.txt"
    llama_model_path = "autodl-tmp/Llama2"
    test_data_path = "our/data/age/test.json"
    model_dir = "our/models"

    # 加载数据
    print("Loading training data and trigger candidates...")
    train_data = load_data(train_data_path)
    candidates = load_candidates(candidate_path)
    test_data = load_data(test_data_path)
    llama_model, llama_tokenizer = load_llama_model(llama_model_path)

    # 初始化并训练模型
    print("Initializing and training model...")
    selector = ImprovedIBTriggerSelector(candidates, train_data, llama_model, llama_tokenizer, beta=0.1, alpha=0.5, gamma=0.2, save_dir=model_dir)
    selector.train(epochs=100)

    # 获取最新的模型文件
    print("Loading latest trained models...")
    enc_model_path = get_latest_model_path(model_dir, "encoder")
    selector.load_models(enc_model_path)

    # 测试最佳触发器
    print("Selecting best trigger...")
    best_trigger, best_score, trigger_metrics = selector.select_best_trigger(test_data)
    print(f"Best Trigger: {best_trigger}, Score: {best_score:.4f}")
    print("\nTop 5 Triggers:")
    for i, metric in enumerate(trigger_metrics[:5], 1):
        print(f"[{i}] Trigger: {metric['trigger']}, Score: {metric['score']:.4f}, "
              f"Bias Score: {metric['bias_score']:.4f}, Perplexity: {metric['perplexity']:.4f}, Mutual Info: {metric['mutual_info']:.4f}")

    # 保存测试结果
    results_path = os.path.join(model_dir, f"bias_induction_results_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json")
    with open(results_path, 'w', encoding='utf-8') as f:
        json.dump(trigger_metrics, f, ensure_ascii=False, indent=2)
    print(f"Test results saved to {results_path}")

if __name__ == "__main__":
    main()